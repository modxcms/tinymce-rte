<?php
/**
 * Default Lexicon Entries for TinyMCE Rich Text Editor
 *
 * @package tinymcerte
 * @subpackage lexicon
 */
$_lang['tinymcerte'] = 'TinyMCE Rich Text Editor';
$_lang['tinymcerte.float_left'] = 'Links';
$_lang['tinymcerte.float_none'] = 'Ohne';
$_lang['tinymcerte.float_right'] = 'Rechts';
$_lang['tinymcerte.select_none'] = '(Keine)';
$_lang['tinymcerte.select_resource'] = 'Ressource wählen';
