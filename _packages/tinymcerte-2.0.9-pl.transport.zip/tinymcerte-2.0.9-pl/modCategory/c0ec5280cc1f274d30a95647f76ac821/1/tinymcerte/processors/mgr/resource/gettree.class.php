<?php
/**
 * Get tree
 *
 * @package tinymcerte
 * @subpackage processors
 */

use TinyMCERTE\Processors\GetTreeProcessor;

/**
 * Class TinyMCERTEGetTreeProcessor
 */
class TinyMCERTEGetTreeProcessor extends GetTreeProcessor
{
}

return 'TinyMCERTEGetTreeProcessor';
