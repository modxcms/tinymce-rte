<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
      'modx' => '>=2.7',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a072974731dd8073329f824b965bafc6',
      'native_key' => 'tinymcerte',
      'filename' => 'modNamespace/3fb07feba0bf71e28915ff038a1154bd.vehicle',
      'namespace' => 'tinymcerte',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b517a7fa5f2c082d26947a9e85999d5a',
      'native_key' => 'tinymcerte.plugins',
      'filename' => 'modSystemSetting/53defbe1b4f3bf860e742a23fa7bbbe6.vehicle',
      'namespace' => 'tinymcerte',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '774836a433ee828568c449a1e09278a7',
      'native_key' => 'tinymcerte.menubar',
      'filename' => 'modSystemSetting/221158f5eb824364a83df4810cb405cc.vehicle',
      'namespace' => 'tinymcerte',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04b0418da86f74ffd15c473028e4dada',
      'native_key' => 'tinymcerte.statusbar',
      'filename' => 'modSystemSetting/e038fbd01c56be9f54ac3b0af63f41c8.vehicle',
      'namespace' => 'tinymcerte',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4d2967141f8c1edb824a1d50970bef9',
      'native_key' => 'tinymcerte.image_advtab',
      'filename' => 'modSystemSetting/684c6a68ec6edb0a94b1ac59a775282f.vehicle',
      'namespace' => 'tinymcerte',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c014d4790f6181d75d21b2bbd92cbd4a',
      'native_key' => 'tinymcerte.object_resizing',
      'filename' => 'modSystemSetting/b4a05568f507ff23d410b91513308084.vehicle',
      'namespace' => 'tinymcerte',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7f7adfccda775218443acaeb624893b',
      'native_key' => 'tinymcerte.paste_as_text',
      'filename' => 'modSystemSetting/e03c8f2e4bf2a2acae64e5b989d0e8d4.vehicle',
      'namespace' => 'tinymcerte',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c785bc8b0c04856ad5963452d40fb926',
      'native_key' => 'tinymcerte.link_class_list',
      'filename' => 'modSystemSetting/a4bc7976d03b99ee53709b2bfda57de3.vehicle',
      'namespace' => 'tinymcerte',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2fbb548060d0b8bb258dabbace912a87',
      'native_key' => 'tinymcerte.browser_spellcheck',
      'filename' => 'modSystemSetting/413ae3b8e6521730f90da4c40e845898.vehicle',
      'namespace' => 'tinymcerte',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df798414eb471260116a00425a177c5a',
      'native_key' => 'tinymcerte.content_css',
      'filename' => 'modSystemSetting/11f76c4dce75c539ebe70f38af17896f.vehicle',
      'namespace' => 'tinymcerte',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '363a08fcd8ceef12281f9451928e99a3',
      'native_key' => 'tinymcerte.image_class_list',
      'filename' => 'modSystemSetting/987d3c8c15d1c22f1101724424f0e2a1.vehicle',
      'namespace' => 'tinymcerte',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2040e5b0c0d81743bc2ca4f3093dfee2',
      'native_key' => 'tinymcerte.external_config',
      'filename' => 'modSystemSetting/10d1112b67052b0a8224decc2a1068ea.vehicle',
      'namespace' => 'tinymcerte',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78c851af98d27749eae2e506bc6c0abe',
      'native_key' => 'tinymcerte.skin',
      'filename' => 'modSystemSetting/69e967bab40b22a7c6d22b7fe4899c95.vehicle',
      'namespace' => 'tinymcerte',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fe175628065387dc8ba7371ce1672ad5',
      'native_key' => 'tinymcerte.relative_urls',
      'filename' => 'modSystemSetting/5c19885eed7fee90ddda8a0342be42bc.vehicle',
      'namespace' => 'tinymcerte',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3fec5203e4900c646f277f2e5dbf400b',
      'native_key' => 'tinymcerte.remove_script_host',
      'filename' => 'modSystemSetting/7fa6ea23a1aeef4f02bc384d3ff1d111.vehicle',
      'namespace' => 'tinymcerte',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50d5ba36dab5961acf3542706f503d24',
      'native_key' => 'tinymcerte.valid_elements',
      'filename' => 'modSystemSetting/017a240a0b63579bb5b5d178ed2a1d96.vehicle',
      'namespace' => 'tinymcerte',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf406787462646bcac46155ca219f3f3',
      'native_key' => 'tinymcerte.settings',
      'filename' => 'modSystemSetting/90e6745d20024a7eb40aff386422c983.vehicle',
      'namespace' => 'tinymcerte',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd591191d733e8bd5f44b572ac1e121a7',
      'native_key' => 'tinymcerte.toolbar1',
      'filename' => 'modSystemSetting/e21fdff51ad800fc420ff8c0aeaab8ac.vehicle',
      'namespace' => 'tinymcerte',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db010ef736a52f2ae5f7f72a1e4725a5',
      'native_key' => 'tinymcerte.toolbar2',
      'filename' => 'modSystemSetting/ec07e90be6f54a1f6f1cf184de480f4b.vehicle',
      'namespace' => 'tinymcerte',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33d16096af69d9a3c2e387c35e4498d4',
      'native_key' => 'tinymcerte.toolbar3',
      'filename' => 'modSystemSetting/5a6f7b3245f03c0ae5b59b2d0eefcf13.vehicle',
      'namespace' => 'tinymcerte',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7f9d2aefb2349e948b073643eb3ce15',
      'native_key' => 'tinymcerte.style_formats',
      'filename' => 'modSystemSetting/3bb7ee5f16b18a720c7f2d39ed82ec1b.vehicle',
      'namespace' => 'tinymcerte',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '988cc1cdf82edfe99ea5bdb75e9ddec5',
      'native_key' => 'tinymcerte.headers_format',
      'filename' => 'modSystemSetting/e4d6bc1b6b76062b4aab8be9c4139125.vehicle',
      'namespace' => 'tinymcerte',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '728ea48d06afc9382a60d1aae38a8ce7',
      'native_key' => 'tinymcerte.inline_format',
      'filename' => 'modSystemSetting/f8b7aa8578aa0dce8dd01bc5df69ca3c.vehicle',
      'namespace' => 'tinymcerte',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd78e4cbdf43a2e77ba2ab03da77e02d7',
      'native_key' => 'tinymcerte.blocks_format',
      'filename' => 'modSystemSetting/95757ccf6f22fd6ecfab3ee9ad654f76.vehicle',
      'namespace' => 'tinymcerte',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0640978acf007ab73522d2ee24b6629c',
      'native_key' => 'tinymcerte.alignment_format',
      'filename' => 'modSystemSetting/edddd1516d10b90509001f24a0531e7d.vehicle',
      'namespace' => 'tinymcerte',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a80a8f0da4d06f920b2ff0302c11b794',
      'native_key' => 'tinymcerte.style_formats_merge',
      'filename' => 'modSystemSetting/69d2cc5add94812756f11edf3e091197.vehicle',
      'namespace' => 'tinymcerte',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '78178ea2cad4e16e6b40131efc333f38',
      'native_key' => NULL,
      'filename' => 'modCategory/5b38692029a0c415f421d0fe6cc829ac.vehicle',
      'namespace' => 'tinymcerte',
    ),
  ),
);