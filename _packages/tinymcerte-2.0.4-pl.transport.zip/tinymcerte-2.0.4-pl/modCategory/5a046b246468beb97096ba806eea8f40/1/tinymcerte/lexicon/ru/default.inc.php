<?php
/**
 * Default Lexicon Entries for TinyMCE Rich Text Editor
 *
 * @package tinymcerte
 * @subpackage lexicon
 */
$_lang['tinymcerte'] = 'TinyMCE Rich Text Editor';
$_lang['tinymcerte.float_left'] = 'Слева';
$_lang['tinymcerte.float_none'] = 'Нет';
$_lang['tinymcerte.float_right'] = 'Справа';
$_lang['tinymcerte.select_none'] = '(Нет)';
$_lang['tinymcerte.select_resource'] = 'Выберите ресурс';
