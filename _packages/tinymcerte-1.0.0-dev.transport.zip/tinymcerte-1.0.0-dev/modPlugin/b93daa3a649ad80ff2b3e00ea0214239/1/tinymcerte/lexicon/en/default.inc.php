<?php
/**
 * Default English Lexicon Entries for TinyMCE Rich Text Editor
 *
 * @package tinymcerte
 * @subpackage lexicon
 */

$_lang['tinymcerte'] = 'TinyMCE Rich Text Editor';
