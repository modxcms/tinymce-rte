<?php
/**
 * Default Lexicon Entries for TinyMCE Rich Text Editor
 *
 * @package tinymcerte
 * @subpackage lexicon
 */
$_lang['tinymcerte'] = 'TinyMCE-tekstbehandler';
$_lang['tinymcerte.float_left'] = 'Venstre';
$_lang['tinymcerte.float_none'] = 'Ingen';
$_lang['tinymcerte.float_right'] = 'Høyre';
$_lang['tinymcerte.select_none'] = '(Ingen)';
$_lang['tinymcerte.select_resource'] = 'Velg ressurs';
