<?php
/**
 * Get tree
 *
 * @package tinymcerte
 * @subpackage processors
 */

use TinyMCERTE\Processors\GetTreeProcessor;

class TinyMCERTEGetTreeProcessor extends GetTreeProcessor
{
}

return 'TinyMCERTEGetTreeProcessor';
